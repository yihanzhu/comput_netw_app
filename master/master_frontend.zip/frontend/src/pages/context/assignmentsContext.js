// assignmentsContext.js

import { createContext } from 'react';

const AssignmentsContext = createContext();

export default AssignmentsContext;
